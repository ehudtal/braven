jQuery(document).ready(function($){
	$('.color-picker').iris();
});